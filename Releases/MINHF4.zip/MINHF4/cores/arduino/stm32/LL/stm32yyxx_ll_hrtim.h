#ifndef _STM32YYXX_LL_HRTIM_H_
#define _STM32YYXX_LL_HRTIM_H_

#ifdef STM32F3xx
#include "stm32f3xx_ll_hrtim.h"
#endif
#endif /* _STM32YYXX_LL_HRTIM_H_ */
