#ifndef _STM32YYXX_LL_DMAMUX_H_
#define _STM32YYXX_LL_DMAMUX_H_

#ifdef STM32L4xx
#include "stm32l4xx_ll_dmamux.h"
#endif
#endif /* _STM32YYXX_LL_DMAMUX_H_ */
