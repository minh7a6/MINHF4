#ifndef _STM32YYXX_LL_SWPMI_H_
#define _STM32YYXX_LL_SWPMI_H_

#ifdef STM32L4xx
#include "stm32l4xx_ll_swpmi.h"
#endif
#endif /* _STM32YYXX_LL_SWPMI_H_ */
