#ifdef STM32F7xx
#include "stm32f7xx_hal_jpeg.c"
#endif
